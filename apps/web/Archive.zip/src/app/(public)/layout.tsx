import Link from 'next/link';
import { Analytics } from '@vercel/analytics/next';

/**
 * Public/marketing routes only (route group `(public)` does not affect URLs).
 * Admin lives under `app/admin` and uses `admin/layout.tsx` instead.
 */
export default function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <header className="site-header">
        <span className="dot" aria-hidden />
        <Link href="/" className="brand">
          Hunny Bible Tracker
        </Link>
      </header>
      {children}
      <footer className="site-footer">
        <Link href="/privacy">Privacy</Link>
        <Link href="/support">Support</Link>
        <Link href="/terms">Terms</Link>
        <span style={{ marginLeft: 'auto' }}>
          © {new Date().getFullYear()} Hunny Bible Tracker
        </span>
      </footer>
      <Analytics />
    </>
  );
}
