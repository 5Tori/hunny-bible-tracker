-- Compact reading backup storage.
-- Stores one latest backup snapshot per authenticated user.

create table if not exists user_reading_backups (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid not null references auth_users(id) on delete cascade,
  backup_version integer not null,
  payload_jsonb jsonb not null,
  payload_hash text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (auth_user_id),
  check (backup_version >= 1),
  check (jsonb_typeof(payload_jsonb) = 'object')
);

create index if not exists idx_user_reading_backups_updated
  on user_reading_backups (updated_at desc);
